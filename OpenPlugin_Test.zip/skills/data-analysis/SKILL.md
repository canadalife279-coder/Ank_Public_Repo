---
name: data-analysis
description: Analyzes data sets and produces insights.
---

## Overview

This skill analyzes data sets and produces insights.
